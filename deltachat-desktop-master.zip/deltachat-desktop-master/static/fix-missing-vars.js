const process = {env:{}}
const global = {}