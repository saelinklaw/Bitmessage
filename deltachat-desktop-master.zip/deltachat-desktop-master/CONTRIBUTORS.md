# Contributors

| Name                    | GitHub                                                       |
| :---------------------- | :----------------------------------------------------------- |
| **Simon Laux**          | [**@Simon-Laux**](https://github.com/Simon-Laux)             |
| **Lars-Magnus Skog**    |                                                              |
| **Nico de Haen**        |                                                              |
| **Karissa McKelvey**    | [**@karissa**](https://github.com/karissa)                   |
| **Jikstra**             | [**@Jikstra**](https://github.com/Jikstra)                   |
| **Alexander Krotov**    |                                                              |
| **holger krekel**       |                                                              |
| **Emil Lefherz**        |                                                              |
| **maris**               |                                                              |
| **pabzm**               |                                                              |
| **raphael**             |                                                              |
| **MIntrovrt**           |                                                              |
| **Floris Bruynooghe**   |                                                              |
| **Guilhem Grezes**      |                                                              |
| **B. Petersen**         |                                                              |
| **Tobias Mueller**      |                                                              |
| **Hansal Bachkaniwala** |                                                              |
| **jankass**             |                                                              |
| **Asiel Díaz Benítez**  |                                                              |
| **Ozancan Karataş**     |                                                              |
| **Alberto Luaces**      |                                                              |
| **alfaslash**           |                                                              |
| **bb**                  |                                                              |
| **Clemens Tolboom**     |                                                              |
| **dependabot\[bot]**    | [**@dependabot\[bot\]**](https://github.com/dependabot[bot]) |
| **developer**           |                                                              |
| **Harald H**            |                                                              |
| **hnrd**                |                                                              |
| **Hugo**                |                                                              |
| **NeoRon**              |                                                              |
| **Noah**                |                                                              |
| **Oliver Bestwalter**   |                                                              |
| **Pablo**               | [**@pabzm**](https://github.com/pabzm)                       |
| **Paula**               | [**@paulaluap**](https://github.com/paulaluap)               |
| **substack**            |                                                              |
| **zafai**               | [**@zafai**](https://github.com/zafai)                       |
