declare module '@mapbox/geojson-extent'
declare module 'react-qr-reader'

type todo = any
