This directory contains scripts that are helpful for developers when building
or maintaining PyBitmessage.
