softwareName = 'PyBitmessage'
softwareVersion = '0.6.3.2'
