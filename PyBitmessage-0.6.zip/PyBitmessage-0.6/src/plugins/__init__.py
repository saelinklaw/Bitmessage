"""
Simple plugin system based on setuptools
----------------------------------------


"""
# .. include:: pybitmessage.plugins.plugin.rst
