.. mdinclude:: ../README.md

Documentation
-------------
.. toctree::
   :maxdepth: 3

   autodoc/pybitmessage

Legacy pages
------------
.. toctree::
   :maxdepth: 2

   usage
   contribute

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
