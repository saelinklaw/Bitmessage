Usage
=====

GUI
---

Bitmessage has a PyQT GUI_

CLI
---

Bitmessage has a CLI_

API
---

Bitmessage has an XML-RPC API_

.. _GUI: https://bitmessage.org/wiki/PyBitmessage_Help
.. _CLI: https://bitmessage.org/wiki/PyBitmessage_Help
.. _API: https://bitmessage.org/wiki/API_Reference
