Processes
=========

In order to keep the Bitmessage project running, the team runs a number of systems and accounts that form the 
development pipeline and continuous delivery process. We are always striving to improve this process. Towards
that end it is documented here.


Project website
---------------

The bitmessage website_

Github
------

Our official Github_ account is Bitmessage. Our issue tracker is here as well.


BitMessage
----------

We eat our own dog food! You can send us bug reports via the [chan] bitmessage  BM-2cWy7cvHoq3f1rYMerRJp8PT653jjSuEdY


.. _website: https://bitmessage.org
.. _Github: https://github.com/Bitmessage/PyBitmessage

