Testing
=======

Currently there is a Travis job somewhere which runs python setup.py test. This doesn't find any tests when run locally for some reason.
