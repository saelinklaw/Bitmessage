Contributing
============

.. toctree::
   :maxdepth: 2
   :glob:

   contribute.dir/*


- Report_
- Develop_(develop)
- Translate_
- Donate_
- Fork the code and open a PR_ on github
- Search the `issue tracker` on github or open a  new issue
- Send bug report to the chan

.. _Report: https://github.com/Bitmessage/PyBitmessage/issues
.. _Develop: https://github.com/Bitmessage/PyBitmessage
.. _Translate: https://www.transifex.com/bitmessage-project/pybitmessage/
.. _Donate: https://tip4commit.com/github/Bitmessage/PyBitmessage
.. _PR: https://github.com/Bitmessage/PyBitmessage/pulls
.. _`issue tracker`: https://github.com/Bitmessage/PyBitmessage/issues
   contributing/*
