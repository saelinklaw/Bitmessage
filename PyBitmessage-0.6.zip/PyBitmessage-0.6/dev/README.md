This directory contains code for future features, but it's not integrated into
PyBitmessage and may not work at all. Developers can look at it if they are
interested.
