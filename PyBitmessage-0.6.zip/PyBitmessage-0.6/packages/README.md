The `generate.sh` script is obsolete, but is included for historical reasons.

Maintained packages can be obtained:

Windows:
========

https://github.com/Bitmessage/PyBitmessage/releases

Works on Windows XP or higher.


OSX:
====

https://github.com/Bitmessage/PyBitmessage/releases

Works on OSX 10.7.5 or higher


Arch linux:
===========

Releases matching PyBitmessage releases:

https://aur.archlinux.org/packages/pybitmessage-git/

Development snapshot equivalent to the v0.6 git branch:

https://aur.archlinux.org/packages/pybitmessage-dev-git/ 


FreeBSD:
========

Use the FreeBSD ports.
